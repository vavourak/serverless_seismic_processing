import csv
import sys
import json
import time
import boto3
import struct
import pickle
import botocore
from struct import Struct

# Function to convert IBM 4-byte data to IEEE 4-byte
class StructIBM32(object):
    def __init__(self, size):
        self.p24 = float(pow(2, 24))
        self.unpack32int = Struct(">%sL" % size).unpack
    def unpack(self, data):
        int32 = self.unpack32int(data)
        return [self.ibm2ieee(i) for i in int32]
    def ibm2ieee(self, int32):
        if int32 == 0:
            return 0.0
        sign = int32 >> 31 & 0x01
        exponent = int32 >> 24 & 0x7f
        mantissa = (int32 & 0x00ffffff) / self.p24
        return (1 - 2 * sign) * mantissa * pow(16, exponent - 64)
        
# Helper functions needed to read headers
def DecodeTraceHeader(trace_header_raw):
    trace_header = {}
    trace_header['trace_seq_no_all']            = int.from_bytes(trace_header_raw[0:4], byteorder='big', signed=False)
    trace_header['trace_seq_no_file']           = int.from_bytes(trace_header_raw[4:8], byteorder='big', signed=False)
    trace_header['field_record_no_orig']        = int.from_bytes(trace_header_raw[8:12], byteorder='big', signed=False)
    trace_header['trace_no_field_orig']         = int.from_bytes(trace_header_raw[12:16], byteorder='big', signed=False)
    trace_header['energy_source_point_no']      = int.from_bytes(trace_header_raw[16:20], byteorder='big', signed=False)
    trace_header['ensemble_no']                 = int.from_bytes(trace_header_raw[20:24], byteorder='big', signed=False)
    trace_header['ensemble_trace_no']           = int.from_bytes(trace_header_raw[24:28], byteorder='big', signed=False)
    trace_header['trace_id']                    = int.from_bytes(trace_header_raw[28:30], byteorder='big', signed=False)
    trace_header['sum_vertical_traces']         = int.from_bytes(trace_header_raw[30:32], byteorder='big', signed=False)
    trace_header['sum_horizontal_traces']       = int.from_bytes(trace_header_raw[32:34], byteorder='big', signed=False)
    trace_header['data_use']                    = int.from_bytes(trace_header_raw[34:36], byteorder='big', signed=False)
    trace_header['distance_from_source_center'] = int.from_bytes(trace_header_raw[36:40], byteorder='big', signed=False)
    # ... incomplete
    trace_header['group_x']                     = int.from_bytes(trace_header_raw[80:84], byteorder='big', signed=False)
    trace_header['group_y']                     = int.from_bytes(trace_header_raw[84:88], byteorder='big', signed=False)
    trace_header['coord_units']                 = int.from_bytes(trace_header_raw[88:90], byteorder='big', signed=False)
    trace_header['trace_samples']               = int.from_bytes(trace_header_raw[114:116], byteorder='big', signed=False)
    trace_header['sample_interval']             = int.from_bytes(trace_header_raw[116:118], byteorder='big', signed=False)
    trace_header['gain_type']                   = int.from_bytes(trace_header_raw[118:120], byteorder='big', signed=False)
    trace_header['CDP_X']                       = int.from_bytes(trace_header_raw[180:184], byteorder='big', signed=False)
    trace_header['CDP_Y']                       = int.from_bytes(trace_header_raw[184:188], byteorder='big', signed=False)
    trace_header['inline']                      = int.from_bytes(trace_header_raw[188:192], byteorder='big', signed=False)
    trace_header['xline']                       = int.from_bytes(trace_header_raw[192:196], byteorder='big', signed=False)
    trace_header['trace_unit']                  = int.from_bytes(trace_header_raw[202:204], byteorder='big', signed=False) 
    trace_header['inline_custom']               = int.from_bytes(trace_header_raw[232:236], byteorder='big', signed=False)
    trace_header['xline_custom']                = int.from_bytes(trace_header_raw[236:240], byteorder='big', signed=False)

    return trace_header
    

# Main function
def lambda_handler(event, context):

    # Example event payload
    #{
    #    "bucket_in"          : source_bucket,
    #    "folder_in"          : source_folder,
    #    "filename_in"        : source_filename,
    #    "bucket_out"         : name,
    #    "folder_out"         : name,
    #    "bytes_start"        : 1234,
    #    "bytes_stop"         : 1234,
    #    "use_custom_lines"   : 1,
    #    "data_sample_format" : bin_header['data_sample_format']
    #}

    # Keeping track of time for performance monitoring
    start_time = time.time()
    
    # Get payload information
    bucket_in           = event['bucket_in']
    folder_in           = event['folder_in']
    filename_in         = event['filename_in']
    bucket_out          = event['bucket_out']
    folder_out          = event['folder_out']
    bytes_start         = event['bytes_start']
    bytes_stop          = event['bytes_stop']
    use_custom_lines    = event['use_custom_lines']
    data_sample_format  = event['data_sample_format']
    
    # Get S3 object stream
    s3 = boto3.resource('s3')
    segy_obj = s3.Object(bucket_in, f"{folder_in}/{filename_in}")
    segy_stream = segy_obj.get(Range=f'bytes={bytes_start}-{bytes_stop}')['Body']

    # Read through the traces
    trace_amp_mean = []
    while True:
        trace_header_raw = segy_stream.read(240)

        # Check to see if reached end of data stream before trying to parse it (always 33 bytes)
        if sys.getsizeof(trace_header_raw) == 33:
            print("End of data.")
            break

        # Decode trace headers
        trace_header = DecodeTraceHeader(trace_header_raw)
        
        # Decode and calculate sum of trace (does it need to convert from IBM 4-byte?)
        trace_raw = segy_stream.read(trace_header['trace_samples']*4)
        trace_sum = 0
        converter = StructIBM32(1)
        for x in range(4, trace_header['trace_samples']*4, 4):
            if data_sample_format == 1:
                trace_sum = trace_sum + abs(converter.unpack(struct.pack('<L', int(bin(int.from_bytes(trace_raw[x-4:x], byteorder='little', signed=False)), 2)))[0])
            elif data_sample_format == 5:
                trace_sum = trace_sum + abs(struct.unpack('>f', trace_raw[x-4:x])[0])

        # Use custom byte locations for inline/xline? (e.g. from ST10010_1150780_40203.sgy)
        if use_custom_lines == 1:
            trace_amp_mean.append([trace_sum / trace_header['trace_samples'], trace_header['inline_custom'], trace_header['xline_custom']])
        else:
            trace_amp_mean.append([trace_sum / trace_header['trace_samples'], trace_header['group_x'], trace_header['group_y']])

        # Periodic prints to be able to check progress in CloudWatch
        if trace_header["trace_seq_no_all"]%1000 == 0:
            print("Processed trace #{}, elapse time is {:.2f}".format(trace_header['trace_seq_no_all'], time.time() - start_time))
    
    # Put the result arrays of data back in S3 as Pickle files
    s3 = boto3.client('s3')
    response = s3.put_object(Bucket=bucket_out, Key=f"{folder_out}/{filename_in}.{bytes_start}-{bytes_stop}.pkl", Body=pickle.dumps(trace_amp_mean))

    print("S3 put response: {}, total time: {:0.2f} seconds.".format(response, time.time() - start_time))

    return {
        'statusCode': 200,
        'body': json.dumps('SegyBatchProcessMeanAmp completed in {:.2f} seconds!'.format(time.time() - start_time))
    }
